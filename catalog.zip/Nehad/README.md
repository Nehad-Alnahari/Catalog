**INTRODUCTION**
This project aims to create a website using your own database with some tools 
(sqlalchemy, HTML templates, css decoratores, vertual box, python, and vagrant software). 


**TOOLS TO RUN THE WEBSITE** 
you nedd to install some tools:
1. VM on your computer 
2. Python 2
3. vagrant software 
4. VM configuration which you can download it and unzip it : FSND-Virtual-Machine.zip
5. Download or clone my project


**ISTRUCTIONS TO RUN THE PROJECT** 
1. Use your own termenal
2. Hit cd to go to the directory that contains the project
3. Hit cd again to the vagrant file
4. follow the commands bellow:
    # vagrant up
    # vagrant ssh
    # cd /vagrant
5. Now run the database and the website by following the bellow commands
    # python database_setup.py
    # python database_fill.py
    # python games_project.py
6. Now go to yoyr browser and write this path: localhos:8000, and now you are in the wibsite 
7. You can close the website fron the terminal using control and C.

