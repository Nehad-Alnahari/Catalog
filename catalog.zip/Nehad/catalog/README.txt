Place your catalog project in this directory.
